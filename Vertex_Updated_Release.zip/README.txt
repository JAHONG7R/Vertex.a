VERTEX — yangilangan manba fayllari

YUKLASH
1. GitHub repository ichidagi eski index.html, script.js va style.css fayllarini ushbu ZIP ichidagi fayllar bilan almashtiring.
2. supabase-config.js va supabase-auth.js fayllarini o‘zgartirmang; ularni repository ichida saqlang.
3. Fayllar repository root (asosiy papka) ichida bo‘lishi kerak.
4. GitHub Pages yangilanishini kutib, saytni qayta yuklang.

MUHIM
- Supabase script tartibi index.html ichida saqlangan.
- Supabase konfiguratsiya va autentifikatsiya fayllari ushbu ZIPga kiritilmagan va almashtirilmasligi kerak.
- Brauzerda faqat Supabase publishable/anon kalit ishlatilishi kerak. service_role/secret kalitni frontendga joylamang.
- O‘zgarishlardan oldin repository yoki mavjud fayllarning zaxira nusxasini oling.
